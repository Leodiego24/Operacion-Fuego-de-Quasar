import json
import os
import datetime
import uuid
from broker.redis_broker import RedisBroker
from adapters.cache_adapter import CacheAdapter
from resources.utils.position_utils import PostitionUtils


class LambdaExecution():

    def __init__(self, factory: CacheAdapter):
        self.factory = factory
  
    def execute_post(self, body, name):
        self.factory.set_data("key", body)

    def execute_get(self):
        self.factory.get_data("key")

def lambda_handler(event, context):
    url = os.environ.get('cache_url')
    redis = RedisBroker(url)
    lambda_exec = LambdaExecution(redis)

    if(event['httpMethod'] == "POST"):
        return lambda_exec.execute_post(event['body'], event['pathParameters']['satellite_name'])
    else:
        return lambda_exec.execute_get()

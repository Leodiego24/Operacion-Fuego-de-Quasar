import math


class PostitionUtils():

    def get_location(self, a, b, c):
        ax, ay = a['lat'], a['log']
        bx, by = b['lat'], b['log']
        cx, cy = c['lat'], c['log']

        return ((ax + (cx - bx)), (ay + (cy - by)))

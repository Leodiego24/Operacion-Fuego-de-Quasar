import json
import datetime
import uuid
from resources.utils.position_utils import PostitionUtils


class LambdaExecution():
  
  def execute_lambda(self, params):
    reponse = {
        "isBase64Encoded": True,
        "statusCode": 200,
        "headers": {},
        "multiValueHeaders": {},
        "body": {}
    }

    data = json.loads(params)
    if(len(params) != 3):
        reponse = {
            "statusCode": 400,
            "body": "Missing some locations."
            }
        return response
    
    locations = [item['distance'] for item in data]
    messages = [item['message'] for item in data]

    if (len(messages[0]) != len(messages[1]) or len(messages[1]) != len(messages[3])):
        reponse = {
            "statusCode": 400,
            "body": "Messages are not the same size."
            }
        return response

    try:
        reponse['body'] = {
            'location': {'x': 70, 'y':80},
            'message': PostitionUtils.get_message(messages[0], messages[1], messages[2])
            }
        reponse['body'] = json.dumps(reponse['body'])
        return response
    except Exception as ex:
        reponse = {
            "statusCode": 500,
            "body": "Error has occurred: {}.".format(str(ex))
        }
        return response    
    

def lambda_handler(event, context):    
    return LambdaExecution().execute_lambda(event['body'])
